__MODULE__ = "ɪɴғᴏʀᴍᴀsɪ ᴜsᴇʀ"
__HELP__ = """
<blockquote><b>♛ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ɪɴғᴏʀᴍᴀsɪ ᴜsᴇʀ ♛<b>

<blockquote><b>perintah : 
<code>{0}info</code> untuk mengetahui id, dan identitas lainya tentang username yang dimaksud, contoh penggunaan: .info (username)</b></blockquote>
"""
